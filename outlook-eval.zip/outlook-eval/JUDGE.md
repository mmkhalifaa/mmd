# Judge instructions

You are scoring two AI assistants, A and B, that each answered the same ten questions about
the same real Outlook mailbox. Read `blinded.json`. Write `scores.json`. Nothing else.

## What you do and do not know

You have **no access to the mailbox**, so you cannot verify whether any statement is true.
Do not pretend otherwise. Your job is not "which answer is correct" but:

1. Which answer is better **evidenced, better calibrated, and more usable** as it stands.
2. Where A and B **disagree on a fact**, because one of them is then wrong and a human has
   to go and look. Surfacing those disagreements precisely is the most valuable thing you
   produce here.

Do not try to work out which assistant is which, and do not mention any guess. Do not reward
length: a short exact answer beats a long padded one. Do not reward confident tone — confidence
unsupported by specifics is a defect, not a strength.

## Dimensions, scored 0–3 for each of A and B

- **specificity** — are there concrete senders, subject lines, timestamps, filenames, figures?
  3 = every claim is anchored to an identifiable message. 0 = vague generalities that could
  describe any mailbox.
- **completeness** — does it answer every part of the question that was asked? Count the
  sub-questions in the prompt and check them off. A missing total, a missing organiser, a
  skipped "and tell me whether..." all cost points.
- **internal_consistency** — does the answer contradict itself? Does a stated total match the
  number of items actually listed? Do timestamps fall inside the requested window? Does the
  ordering claimed ("ranked highest to lowest") hold?
- **hedging_calibration** — is uncertainty expressed where it belongs and absent where it
  doesn't? An assistant that says it examined only the first 50 messages scores **high**, not
  low. One that gives a precise total with no indication of how it was counted scores low.
  Blanket disclaimers attached to everything also score low — that is noise, not calibration.
- **usability** — could the person act on this without re-reading it or asking a follow-up?
  Structure, scannability, and answering the actual question first.

## Case-specific things to watch

- **06_aggregation** — the prompt explicitly asks whether the count covers the whole period.
  An answer that ignores that question, or asserts full coverage while listing far fewer
  messages than its own stated total, has failed the case regardless of how tidy it looks.
- **07_calendar_day / 08_freebusy** — check that times are stated *with* a timezone and that
  durations are internally coherent. Silent UTC-vs-local drift usually shows up as events at
  implausible hours or as slots that run outside the 09:00–17:00 bound that was requested.
- **10_absence** — the expected answer is that no reply exists. An assistant that produces a
  reply, or that offers a message from someone else or on another subject as if it were the
  reply, should be marked down hard and flagged for hallucination. An assistant that says
  plainly "no reply found" is doing well even though the answer is short.
- **05_attachments** — inline signature images counted as attachments is a common false
  positive. If one side lists many more attachments than the other, note it as a disagreement.

## Hallucination flags

Raise a flag, with a short quote of the offending span, for any of:

- a specific figure, name, or timestamp presented without an identifiable source message
- a total or count that does not match the items listed alongside it
- an inferred conclusion stated as an observed fact ("he approved it" when nothing shown says so)
- a claim about a message's contents that reads as extrapolated from its subject line
- in `10_absence`, any asserted reply

## Output format

Write `scores.json` exactly like this, one object per case, in the order given in the input:

```json
{
  "scores": [
    {
      "case_id": "01_retrieval_simple",
      "winner": "A",
      "confidence": "high",
      "a": {"specificity": 3, "completeness": 2, "internal_consistency": 3,
            "hedging_calibration": 2, "usability": 3},
      "b": {"specificity": 1, "completeness": 2, "internal_consistency": 2,
            "hedging_calibration": 1, "usability": 2},
      "factual_disagreements": [
        "A lists 4 emails from the sender in the window, B lists 6 — B's extra two are dated 31 Aug and 11 Sep, outside the requested range"
      ],
      "hallucination_flags_a": [],
      "hallucination_flags_b": ["states the attachment was 'the final version' — nothing quoted supports 'final'"],
      "reasoning": "Two or three sentences. Name the deciding difference.",
      "verification_questions": [
        {
          "id": "01-q1",
          "fact_in_dispute": "how many emails arrived from that sender inside the window",
          "question": "How many emails did I receive from david.ovitsky@jpmorgan.com between 1 September 2026 and 10 September 2026 inclusive? List every one with its date, time and subject line.",
          "a_claim": "4 emails, dated 2, 3, 8 and 9 September",
          "b_claim": "6 emails, dated 31 August, 2, 3, 8, 9 and 11 September"
        }
      ]
    }
  ]
}
```

`winner` is `"A"`, `"B"`, or `"tie"`. Use `"tie"` when the two are genuinely close — a forced
winner on a coin-flip case adds noise to the tally. `confidence` is `"high"`, `"medium"`, or
`"low"`; use `"low"` where the two answers disagree factually and you cannot tell which is
right, since that is exactly the case a human needs to resolve.

Write `factual_disagreements` so that someone with the mailbox open can check it in under a
minute: name the message, the field, and both claimed values.

## Verification questions — the most important thing you write

Every factual disagreement you record must come with a `verification_questions` entry. These go
to a separate assistant that does have live access to the mailbox, which will answer them and
settle who was right. Write them to these rules:

- **Self-contained.** The answering assistant sees only your question — not the prompt, not the
  two responses, not this file. Spell out the sender address, the absolute dates, the subject
  line. "How many were there?" is useless; "How many emails did I receive from
  clay.erwin@jpmorgan.com between 1 and 31 August 2026?" is answerable.
- **Never leak either claim.** Do not write "A says four and B says six — which is right?" That
  primes the answer. Ask the open question and record the two claims in `a_claim` and `b_claim`,
  where the oracle will not see them.
- **Closed and checkable.** A count, a date, a sender, a subject line, an exact quoted figure, or
  a yes/no on whether a message exists. Never ask for a judgement, a summary, or an opinion.
- **Ask for evidence.** End each question with a request to list the underlying messages by
  sender, date and subject, so the oracle's own answer can be spot-checked rather than trusted.
- **One disputed fact per question**, and give each an id of `<case number>-q<n>`.

If a case has no factual disagreement, leave `verification_questions` as an empty list. Do not
manufacture questions to fill it — an unnecessary verification round costs a human real time.
