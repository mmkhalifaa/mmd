# coach (Graph API) vs Claude Cowork (Outlook MCP) — A/B eval

Ten fixed prompts, run through both tools against your own mailbox, captured by hand, then
scored blind by Claude Code.

## Procedure

1. **Check `cases.json`.** It is already filled in for this mailbox: David Ovitsky as the
   sender, US Eastern as the timezone, the 28 August coach 3.0 metrics email as the needle, and
   the unanswered Clay Erwin / David Frame thread as the absence test. Keep the absolute dates
   as they are. Cases 02 and 10 carry a `your_answer_key` field — you already know the right
   answer for those two, and that field never reaches any judge or oracle.

   `prompts.txt` is the same ten prompts as a plain copy-paste sheet.

2. `python harness.py init` — builds `runs.json` with 20 empty rows.

3. **Run the prompts.** Paste the identical prompt text into coach and into Cowork. Paste each
   response back into the matching `response` field, verbatim — don't tidy the formatting, since
   formatting is one of the things being scored. Note `latency_seconds` roughly and
   `tool_calls` if either tool shows them.

   Run cases 07, 08 and 09 in both tools on the same day. They read forward-looking calendar
   data, so a day's gap means the two tools saw different calendars.

   Start a fresh session per prompt in both tools. Context bleed from the previous answer is
   the most common way a comparison like this gets quietly contaminated.

4. `python harness.py blind` — writes `blinded.json` (tool names stripped, A/B order
   randomised per case) and `key.json`.

5. **Judge.** In Claude Code, point it at `JUDGE.md` and `blinded.json`:

   > Read JUDGE.md and follow it. Score blinded.json and write scores.json.

   Hand over `blinded.json` only. `key.json` must stay out of the judge's context or the blind
   is gone.

6. `python harness.py verify` — reads the judge's verification questions and writes
   `verify.json` plus `verify_questions.txt`, a paste sheet of closed factual questions.

7. **Adjudicate with the oracle.** Answer each question in Microsoft Copilot — one per fresh
   session — and paste its answer verbatim into the matching `oracle_answer` field in
   `verify.json`. Never show Copilot either candidate answer, and never tell it there is a
   comparison happening. It is a witness, not a judge.

   Then, in Claude Code:

   > Read ADJUDICATE.md and follow it. Adjudicate verify.json and write verdicts.json.

8. `python harness.py unblind` — merges scores and verdicts back onto the real tool names,
   writes `final.json` and `report.md`.

9. `python harness.py export` — writes `results.xlsx` (needs `openpyxl`).

If you skip steps 6-7, `unblind` still works and you get the preference tally alone.

## The two measures, and which one to trust

The report gives you a **blind preference tally** and a **verified accuracy tally**. They answer
different questions and they will sometimes disagree, which is the most useful thing the eval can
tell you. Preference says which answer read better: structured, specific, calibrated, usable.
Accuracy says which one was actually right about the mailbox. A tool that wins on preference and
loses on accuracy is the dangerous one — it is producing confident, well-formatted, wrong answers,
and that is worse in production than a tool that hedges visibly.

Weight accuracy higher when you write up the result. Preference is a proxy; accuracy is the thing.

## Three assistants, one of which is also fallible

Copilot is a third Outlook integration with its own search behaviour, pagination limits and
truncation habits. It is a strong independent witness, not ground truth. That is why the oracle
questions ask it to list the underlying messages by sender, date and subject: so you can sanity-
check its answer in seconds rather than taking it on faith, and why the adjudicator is instructed
to mark a vague or truncated oracle answer `unresolved` instead of forcing a verdict.

The useful pattern to watch for: where all three agree, you can stop thinking about that case.
Where Copilot sides with one candidate, the other is probably wrong. Where all three differ, that
case lands on the short list in `report.md` under "Still needs your eyes", and those are worth
opening the mailbox for.

## Your mailbox moves

Every prompt uses absolute dates for this reason, but new mail still arrives between your coach
run and your Cowork run. Run each pair back to back, same sitting, and note in `capture_notes` if
anything looked like it shifted. Do the oracle round promptly too — a verification question
answered three weeks later is answered against a different mailbox.

## Scope and privacy

`runs.json`, `blinded.json`, `verify.json` and the exports will contain real email content — senders, subject
lines, quoted bodies. Keep them wherever your mailbox data is allowed to live, and remember that the judging
steps send that content to Claude Code and the oracle round sends questions about it to
Microsoft Copilot.

## Getting more out of it

- **Three runs, not one.** Both stacks are non-deterministic. A single run tells you about one
  sample, not about the tools. Re-run with `--run-id`, judge each separately, and look at which
  cases flip — a case that flips is telling you the difference there is noise.
- **Add write-path cases** (draft a reply, create an event) once the read path is solid. They
  need a test mailbox rather than your live one.
- **Keep the ten prompts frozen** across versions of both integrations. The set becomes a
  regression suite, and that's worth more than any single comparison.
