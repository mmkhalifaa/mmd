# Adjudication instructions

Read `verify.json`. Write `verdicts.json`. Nothing else.

Each entry contains a closed factual question about a real Outlook mailbox, an `oracle_answer`
from an assistant that has live access to that mailbox, and two claims, `a_claim` and `b_claim`,
made by the two assistants being evaluated. Your job is narrow: decide whether each claim matches
the oracle's answer.

## Rules

- **Compare, do not reason about the mailbox.** You have no access to it. The oracle's answer is
  the only evidence you have. Never fill a gap in it with an assumption about what is probably
  in someone's inbox.
- **The oracle is a witness, not an authority.** If its answer is vague, hedged, internally
  inconsistent, visibly truncated ("here are the first 25..."), refuses, or does not actually
  address the question asked, set `oracle_usable` to `false` and mark both claims `unresolved`.
  Say why in `note`. Do not stretch a partial answer into a verdict — a false verdict is worse
  than an unresolved one, because nobody will go back and check it.
- **Silence is not agreement.** If the oracle lists four messages and a claim mentions a fifth
  that the oracle simply does not discuss, that is `unresolved` for that detail, not `incorrect`.
  An oracle answer that explicitly claims completeness ("those are all of them") does let you
  mark an extra item `incorrect`.
- **Judge the disputed fact only.** Ignore tone, length, formatting and anything else the claim
  happens to contain. Those were scored elsewhere.

## Verdicts

For each of `a` and `b`, one of:

- `correct` — matches the oracle on the disputed fact, including the specifics
- `partial` — right in substance, wrong in detail: the correct count with one date wrong, a
  correct subset presented as the complete set, the right figure attributed to the wrong sender
- `incorrect` — contradicts the oracle on the disputed fact
- `unresolved` — the oracle's answer does not settle it

## Output format

```json
{
  "verdicts": [
    {
      "question_id": "01-q1",
      "oracle_usable": true,
      "a": "correct",
      "b": "partial",
      "note": "Oracle lists 4 messages, dated 2, 3, 8 and 9 September, and states those are all. B's count is right for its own list but two of its items fall outside the requested window."
    }
  ]
}
```

Keep `note` to one or two sentences, and make it quote or cite the part of the oracle answer you
relied on, so a human re-reading this later can see what the verdict rested on.
