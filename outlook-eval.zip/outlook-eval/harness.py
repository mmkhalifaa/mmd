#!/usr/bin/env python3
"""Outlook integration A/B harness: coach (Graph API) vs Claude Cowork (Outlook MCP).

Workflow
--------
  python harness.py init                 -> runs.json   (paste your outputs into this)
  python harness.py blind                -> blinded.json + key.json
  ... hand blinded.json + JUDGE.md to Claude Code, which writes scores.json ...
  python harness.py unblind              -> final.json + report.md
  python harness.py export               -> results.xlsx

Only blinded.json goes to the judge. key.json stays put until scoring is done.
"""

import argparse
import json
import random
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).parent
TOOLS = ["coach", "cowork"]
DIMENSIONS = [
    "specificity",
    "completeness",
    "internal_consistency",
    "hedging_calibration",
    "usability",
]


def load(name):
    path = HERE / name
    if not path.exists():
        sys.exit(f"missing {name} — run the previous step first")
    return json.loads(path.read_text())


def save(name, obj):
    (HERE / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False))
    print(f"wrote {name}")


def cmd_init(args):
    cases = load("cases.json")["cases"]
    out = {
        "run_id": args.run_id or datetime.now(timezone.utc).strftime("run-%Y%m%d-%H%M"),
        "captured_at": None,
        "mailbox": "",
        "tools": {
            "coach": {"backend": "microsoft-graph-api", "version": ""},
            "cowork": {"backend": "outlook-mcp-server", "version": ""},
        },
        "results": [],
    }
    for case in cases:
        for tool in TOOLS:
            out["results"].append(
                {
                    "case_id": case["id"],
                    "tool": tool,
                    "prompt_sent": case["prompt"],
                    "response": "",
                    "latency_seconds": None,
                    "tool_calls": None,
                    "error": "",
                    "capture_notes": "",
                }
            )
    save(args.out, out)
    print(
        f"\n{len(out['results'])} rows to fill.\n"
        "Fill in the placeholders in prompt_sent first, paste the same text into both "
        "tools, then paste each response verbatim into `response`. Do not tidy the "
        "output — formatting is part of what you are judging."
    )


def cmd_blind(args):
    runs = load(args.runs)
    by_case = {}
    for row in runs["results"]:
        by_case.setdefault(row["case_id"], {})[row["tool"]] = row

    rng = random.Random(args.seed)
    blinded, key = [], []
    skipped = []

    for case_id, pair in by_case.items():
        if not all(pair.get(t, {}).get("response", "").strip() for t in TOOLS):
            skipped.append(case_id)
            continue
        order = TOOLS[:]
        rng.shuffle(order)
        a_tool, b_tool = order
        blinded.append(
            {
                "case_id": case_id,
                "prompt": pair[a_tool]["prompt_sent"],
                "response_a": pair[a_tool]["response"],
                "response_b": pair[b_tool]["response"],
            }
        )
        key.append({"case_id": case_id, "A": a_tool, "B": b_tool})

    if skipped:
        print(f"skipped (response still empty): {', '.join(skipped)}")
    if not blinded:
        sys.exit("nothing to blind — no case has both responses captured")

    save(args.blinded, {"run_id": runs["run_id"], "cases": blinded})
    save(args.key, {"run_id": runs["run_id"], "seed": args.seed, "mapping": key})
    print("\nSend ONLY blinded.json to the judge. Keep key.json closed until scoring is done.")


def cmd_verify(args):
    """Pull the judge's verification questions into a paste sheet for the oracle."""
    scores = load(args.scores)["scores"]
    items = []
    for s in scores:
        for q in s.get("verification_questions", []) or []:
            items.append(
                {
                    "question_id": q.get("id", f"{s['case_id']}-q?"),
                    "case_id": s["case_id"],
                    "fact_in_dispute": q.get("fact_in_dispute", ""),
                    "question": q["question"],
                    "a_claim": q.get("a_claim", ""),
                    "b_claim": q.get("b_claim", ""),
                    "oracle_answer": "",
                    "oracle_notes": "",
                }
            )
    if not items:
        print("no factual disagreements to verify — the judge raised none")
        return

    save(args.verify, {"oracle": args.oracle, "questions": items})

    sheet = [
        "ORACLE VERIFICATION QUESTIONS",
        f"Answer each of these in {args.oracle}, one per FRESH session.",
        "Paste the answer verbatim into the matching `oracle_answer` field in verify.json.",
        "Do not tell it about the two answers being compared, and do not paste them in.",
        "=" * 72,
        "",
    ]
    for it in items:
        sheet += [f"--- {it['question_id']} ---", "", it["question"], "", ""]
    (HERE / args.sheet).write_text("\n".join(sheet))
    print(f"wrote {args.sheet}  ({len(items)} question(s))")
    print(
        "\nThe claims are stored in verify.json but are NOT in the paste sheet — "
        "that is deliberate. Showing the oracle either claim makes its answer worthless."
    )


def cmd_unblind(args):
    runs = load(args.runs)
    key = {m["case_id"]: m for m in load(args.key)["mapping"]}
    scores = load(args.scores)["scores"]

    metrics = {}
    for row in runs["results"]:
        metrics[(row["case_id"], row["tool"])] = row

    verdicts = {}
    if (HERE / args.verdicts).exists():
        for v in json.loads((HERE / args.verdicts).read_text())["verdicts"]:
            verdicts.setdefault(v["question_id"].split("-")[0], []).append(v)
        print(f"folding in {sum(len(v) for v in verdicts.values())} oracle verdict(s)")

    final, tally = [], Counter()
    accuracy = {t: Counter() for t in TOOLS}
    for s in scores:
        cid = s["case_id"]
        if cid not in key:
            print(f"warning: {cid} scored but not in key — skipping")
            continue
        m = key[cid]
        winner = {"A": m["A"], "B": m["B"], "tie": "tie"}.get(s.get("winner", "tie"), "tie")
        tally[winner] += 1

        case_verdicts = verdicts.get(cid.split("_")[0], [])
        resolved = []
        for v in case_verdicts:
            resolved.append(
                {
                    "question_id": v["question_id"],
                    "oracle_usable": v.get("oracle_usable", True),
                    "note": v.get("note", ""),
                    "by_tool": {m["A"]: v.get("a", "unresolved"),
                                m["B"]: v.get("b", "unresolved")},
                }
            )
            accuracy[m["A"]][v.get("a", "unresolved")] += 1
            accuracy[m["B"]][v.get("b", "unresolved")] += 1

        entry = {"case_id": cid, "winner": winner, "confidence": s.get("confidence", ""),
                 "reasoning": s.get("reasoning", ""),
                 "factual_disagreements": s.get("factual_disagreements", []),
                 "oracle_verdicts": resolved,
                 "by_tool": {}}
        for slot, tool in (("a", m["A"]), ("b", m["B"])):
            dims = s.get(slot, {}) or {}
            row = metrics.get((cid, tool), {})
            entry["by_tool"][tool] = {
                "dimensions": {d: dims.get(d) for d in DIMENSIONS},
                "total": sum(v for v in (dims.get(d) for d in DIMENSIONS) if isinstance(v, (int, float))),
                "hallucination_flags": s.get(f"hallucination_flags_{slot}", []),
                "latency_seconds": row.get("latency_seconds"),
                "tool_calls": row.get("tool_calls"),
                "error": row.get("error", ""),
            }
        final.append(entry)

    save(args.final, {"run_id": runs["run_id"], "tally": dict(tally),
                      "accuracy": {t: dict(c) for t, c in accuracy.items()},
                      "cases": final})

    lines = [f"# {runs['run_id']} — coach vs cowork", "",
             f"Cases scored: {len(final)}", "", "## Blind preference", ""]
    for tool in TOOLS:
        lines.append(f"- **{tool}** wins: {tally.get(tool, 0)}")
    lines.append(f"- ties: {tally.get('tie', 0)}")

    if any(accuracy[t] for t in TOOLS):
        lines += ["", "## Verified accuracy on disputed facts", "",
                  "Adjudicated against the oracle. This is the harder of the two measures — "
                  "the preference tally says which answer read better, this says which one "
                  "was right.", "",
                  "| Tool | Correct | Partial | Incorrect | Unresolved |",
                  "|---|---|---|---|---|"]
        for tool in TOOLS:
            a = accuracy[tool]
            lines.append(f"| {tool} | {a.get('correct', 0)} | {a.get('partial', 0)} | "
                         f"{a.get('incorrect', 0)} | {a.get('unresolved', 0)} |")
    lines += ["", "## Per case", "",
              "| Case | Winner | Conf | coach pts | cowork pts | Disagreements |",
              "|---|---|---|---|---|---|"]
    for e in final:
        pts = {t: e["by_tool"].get(t, {}).get("total", "") for t in TOOLS}
        lines.append(
            f"| {e['case_id']} | {e['winner']} | {e['confidence']} | "
            f"{pts['coach']} | {pts['cowork']} | {len(e['factual_disagreements'])} |"
        )
    unresolved = [(e["case_id"], v) for e in final for v in e["oracle_verdicts"]
                  if not v["oracle_usable"]
                  or "unresolved" in v["by_tool"].values()]
    open_disputes = [(e["case_id"], d) for e in final for d in e["factual_disagreements"]
                     if not e["oracle_verdicts"]]

    if unresolved or open_disputes:
        lines += ["", "## Still needs your eyes", "",
                  "Neither the judge nor the oracle could settle these. Open the mailbox and "
                  "resolve them by hand — it is a short list, and it is where the real "
                  "quality signal lives.", ""]
        for cid, v in unresolved:
            reason = "oracle answer unusable" if not v["oracle_usable"] else "oracle did not settle it"
            lines.append(f"- **{cid}** / {v['question_id']} — {reason}. {v['note']}")
        for cid, d in open_disputes:
            lines.append(f"- **{cid}** — no verification question was raised: {d}")
    (HERE / args.report).write_text("\n".join(lines) + "\n")
    print(f"wrote {args.report}")


def cmd_export(args):
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font
    except ImportError:
        sys.exit("openpyxl not installed — pip install openpyxl")

    final = load(args.final)
    cases = final["cases"]
    wb = Workbook()
    base = Font(name="Arial", size=10)
    head = Font(name="Arial", size=10, bold=True)

    ws = wb.active
    ws.title = "Scores"
    cols = ["Case", "Winner", "Confidence"]
    for tool in TOOLS:
        cols += [f"{tool}: {d}" for d in DIMENSIONS] + [f"{tool}: total",
                                                        f"{tool}: latency (s)",
                                                        f"{tool}: tool calls"]
    ws.append(cols)
    for r, e in enumerate(cases, start=2):
        row = [e["case_id"], e["winner"], e["confidence"]]
        for tool in TOOLS:
            t = e["by_tool"].get(tool, {})
            dims = t.get("dimensions", {})
            row += [dims.get(d) for d in DIMENSIONS]
            row += [t.get("total"), t.get("latency_seconds"), t.get("tool_calls")]
        ws.append(row)

    last = len(cases) + 1
    ws.append([])
    tally_row = last + 2
    ws.cell(row=tally_row, column=1, value="Wins")
    for i, tool in enumerate(TOOLS):
        ws.cell(row=tally_row + i, column=2, value=tool)
        ws.cell(row=tally_row + i, column=3,
                value=f'=COUNTIF(B2:B{last},"{tool}")')
    ws.cell(row=tally_row + len(TOOLS), column=2, value="tie")
    ws.cell(row=tally_row + len(TOOLS), column=3, value=f'=COUNTIF(B2:B{last},"tie")')

    ws2 = wb.create_sheet("Disputed facts")
    ws2.append(["Case", "Question", "Disagreement"] + [f"{t} verdict" for t in TOOLS]
               + ["Oracle usable", "Adjudicator note"])
    for e in cases:
        for v in e.get("oracle_verdicts", []):
            ws2.append([e["case_id"], v["question_id"], "",
                        *[v["by_tool"].get(t, "") for t in TOOLS],
                        "yes" if v["oracle_usable"] else "NO", v["note"]])
        if not e.get("oracle_verdicts"):
            for d in e["factual_disagreements"]:
                ws2.append([e["case_id"], "not verified", d, "", "", "", ""])
    for col in ("C", "G"):
        ws2.column_dimensions[col].width = 70

    acc = final.get("accuracy", {})
    if any(acc.values()):
        ws4 = wb.create_sheet("Accuracy")
        ws4.append(["Tool", "Correct", "Partial", "Incorrect", "Unresolved"])
        for tool in TOOLS:
            a = acc.get(tool, {})
            ws4.append([tool, a.get("correct", 0), a.get("partial", 0),
                        a.get("incorrect", 0), a.get("unresolved", 0)])

    ws3 = wb.create_sheet("Flags & reasoning")
    ws3.append(["Case", "Tool", "Hallucination flags", "Judge reasoning"])
    for e in cases:
        for tool in TOOLS:
            t = e["by_tool"].get(tool, {})
            ws3.append([e["case_id"], tool, "; ".join(t.get("hallucination_flags", [])),
                        e["reasoning"] if tool == TOOLS[0] else ""])
    ws3.column_dimensions["C"].width = 50
    ws3.column_dimensions["D"].width = 80

    for sheet in wb.worksheets:
        sheet.freeze_panes = "A2"
        for row in sheet.iter_rows():
            for cell in row:
                cell.font = head if cell.row == 1 else base
                cell.alignment = Alignment(vertical="top", wrap_text=cell.column > 2)
        sheet.column_dimensions["A"].width = 24

    wb.save(HERE / args.xlsx)
    print(f"wrote {args.xlsx}")


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    i = sub.add_parser("init", help="build an empty runs.json to paste into")
    i.add_argument("--out", default="runs.json")
    i.add_argument("--run-id", default=None)
    i.set_defaults(func=cmd_init)

    b = sub.add_parser("blind", help="strip tool names, randomise A/B order")
    b.add_argument("--runs", default="runs.json")
    b.add_argument("--blinded", default="blinded.json")
    b.add_argument("--key", default="key.json")
    b.add_argument("--seed", type=int, default=1)
    b.set_defaults(func=cmd_blind)

    v = sub.add_parser("verify", help="build the oracle question sheet from the judge's scores")
    v.add_argument("--scores", default="scores.json")
    v.add_argument("--verify", default="verify.json")
    v.add_argument("--sheet", default="verify_questions.txt")
    v.add_argument("--oracle", default="Microsoft Copilot")
    v.set_defaults(func=cmd_verify)

    u = sub.add_parser("unblind", help="merge judge scores and oracle verdicts onto tool names")
    u.add_argument("--runs", default="runs.json")
    u.add_argument("--key", default="key.json")
    u.add_argument("--scores", default="scores.json")
    u.add_argument("--verdicts", default="verdicts.json")
    u.add_argument("--final", default="final.json")
    u.add_argument("--report", default="report.md")
    u.set_defaults(func=cmd_unblind)

    e = sub.add_parser("export", help="write results.xlsx from final.json")
    e.add_argument("--final", default="final.json")
    e.add_argument("--xlsx", default="results.xlsx")
    e.set_defaults(func=cmd_export)

    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
