// The AI, called from the browser without ever exposing the key.
// Set ANTHROPIC_API_KEY in the site's environment variables. Optional: ANTHROPIC_MODEL, EVENT_CODE.
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });

export default async (req) => {
  if (req.method !== 'POST') return json({ error: 'method' }, 405);
  const eventCode = process.env.EVENT_CODE || '';
  if (eventCode && req.headers.get('x-event-code') !== eventCode) return json({ error: 'event code' }, 401);
  const key = process.env.ANTHROPIC_API_KEY; if (!key) return json({ error: 'ANTHROPIC_API_KEY is not set' }, 500);
  let body; try { body = await req.json(); } catch (e) { return json({ error: 'body' }, 400); }
  const system = String(body.system || '').slice(0, 8000); const user = String(body.user || '').slice(0, 12000);
  if (!user) return json({ error: 'empty' }, 400);
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6', max_tokens: 1000, system, messages: [{ role: 'user', content: user }] })
  });
  if (!res.ok) return json({ error: 'upstream ' + res.status, detail: (await res.text()).slice(0, 300) }, 502);
  const data = await res.json();
  const text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
  return json({ text });
};
