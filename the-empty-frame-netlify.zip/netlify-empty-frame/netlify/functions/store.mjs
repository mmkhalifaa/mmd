// Shared event data: one key-value store on Netlify Blobs.
// Every request must carry the event code (X-Event-Code) if EVENT_CODE is set.
// Writing "meta" and deleting anything also needs the team code (X-Team-Code).
import { getStore } from '@netlify/blobs';

const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
const okKey = (k) => typeof k === 'string' && k.length > 0 && k.length < 200 && /^[A-Za-z0-9:_\-.]+$/.test(k);

export default async (req) => {
  const eventCode = process.env.EVENT_CODE || '';
  const teamCode = process.env.TEAM_CODE || 'EFL';
  if (eventCode && req.headers.get('x-event-code') !== eventCode) return json({ error: 'event code' }, 401);
  const store = getStore('empty-frame');
  const url = new URL(req.url);
  const isTeam = req.headers.get('x-team-code') === teamCode;
  try {
    if (req.method === 'GET') {
      const prefix = url.searchParams.get('prefix');
      if (prefix !== null) { const { blobs } = await store.list({ prefix }); return json({ keys: blobs.map((b) => b.key) }); }
      const key = url.searchParams.get('key'); if (!okKey(key)) return json({ error: 'key' }, 400);
      const value = await store.get(key); if (value === null) return json({ error: 'not found' }, 404);
      return json({ key, value });
    }
    if (req.method === 'PUT' || req.method === 'POST') {
      const body = await req.json(); const { key, value } = body || {};
      if (!okKey(key) || typeof value !== 'string') return json({ error: 'body' }, 400);
      if (value.length > 4 * 1024 * 1024) return json({ error: 'too large' }, 413);
      if ((key === 'meta' || key.endsWith(':meta')) && !isTeam) return json({ error: 'team code' }, 403);
      await store.set(key, value); return json({ key });
    }
    if (req.method === 'DELETE') {
      if (!isTeam) return json({ error: 'team code' }, 403);
      const key = url.searchParams.get('key'); if (!okKey(key)) return json({ error: 'key' }, 400);
      await store.delete(key); return json({ key, deleted: true });
    }
    return json({ error: 'method' }, 405);
  } catch (e) { return json({ error: String(e && e.message || e) }, 500); }
};
