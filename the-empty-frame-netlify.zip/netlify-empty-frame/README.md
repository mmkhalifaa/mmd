# The Empty Frame on Netlify

One static page plus two small functions. Netlify hosts all three; nothing else is needed.

```
public/index.html            the app (participants and facilitators use the same link)
netlify/functions/store.mjs  the shared event data, on Netlify Blobs
netlify/functions/ai.mjs     the AI, called with a key that never leaves the server
netlify.toml                 routing: /api/store and /api/ai
package.json                 one dependency, @netlify/blobs
```

## Deploy, first time (about ten minutes)

1. Create a free Netlify account, then a new project. Either connect a Git repository that contains this folder, or use the Netlify CLI: `npm install -g netlify-cli`, then in this folder `netlify login`, `netlify init`, `netlify deploy --prod`. (Drag-and-drop deploys do not build functions, so use one of these two routes.)
2. In the project's settings, add three environment variables:
   - `ANTHROPIC_API_KEY`: an API key from console.anthropic.com. The app never sends it to the browser.
   - `EVENT_CODE`: a short code participants type once, e.g. `forum26`. Change it for every event.
   - `TEAM_CODE`: the facilitators' code for the back end, e.g. `EFL-2026`.
   Optional: `ANTHROPIC_MODEL` to choose a model (defaults to `claude-sonnet-4-6`).
3. Redeploy after setting the variables (functions read them at start).
4. Open the site URL. Enter the team code, name the event, load the five sample stories, and run through the six steps once.

## On the day

- Participants open the same URL on their phones (a QR code on a slide works well), type the event code, and follow the four screens: disclosure, name, photo, two questions.
- The facilitator's screen shows submissions as they arrive. Read the stories, present the wall, open the tokens; the phones update within ten seconds. The room screen updates every five seconds and can be projected.
- Afterwards, "Clear the event" in the Notes drawer removes every submission from Netlify. Change `EVENT_CODE` before the next event.

## What is stored, and where

- Photographs and answers are stored in Netlify Blobs for the site, until cleared. They are sent to the browsers of anyone with the event code, which is the point of the wall.
- The written answers (never the photographs) are sent to the Anthropic API through the `ai` function.
- Each browser keeps its own progress locally so that a refreshed phone does not lose its place.

Check with your compliance and information-security teams before using this with client data. The same two functions can be hosted on the bank's own infrastructure with no change to the page; they are about 40 lines each.
