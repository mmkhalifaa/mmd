# ADVISER_EVENT_INSIGHTS.md — What a great adviser could have known, said, and done
### Reference rubric for Claude Code (pilot + full build). Facts verified Aug 2026; derived stats computed from market_daily.csv.

## How to use this file — and how not to
- **Use it as a rubric,** to recognize and grade the guidance found in call notes, and to know which client questions were predictable vs which adviser moves were genuinely rare.
- **Never use it as evidence.** Nothing here says what OUR advisers actually did — only the notes do.
- **Guard against hindsight bias.** Every playbook item carries a *knowable-from* date. An adviser gets credit only for advice that was knowable when they gave it. Advice that happened to work by luck ≠ Tier 3; sound advice that got unlucky ≠ bad advice.

## Guidance-quality tiers (tag every adviser position you find)
- **T0 · Generic reassurance:** "markets go up and down, stay calm." Not wrong, not differentiated.
- **T1 · Sound standard practice:** stay invested, revisit risk tolerance, rebalance on schedule.
- **T2 · Event-specific and actionable:** tax-loss harvest this drawdown; rebalance INTO the selloff per policy bands; don't chase gold at these levels; lock cash into yield instead of waiting for cuts.
- **T3 · Anticipatory or contrarian with reasoning:** acted before the anchor date, or against the herd, with an articulated mechanism ("if the Strait closes, energy is the hedge — equities and bonds may fall together on an inflation shock").
Herd = mostly T0–T1. The moat story = concentration of T2–T3 in a small set of bankers, early.

---

# EVENT DEEP DIVE · HORMUZ WAR (pilot window Feb 20 – Mar 31, 2026)

## The tape (verified / computed from market_daily.csv)
- Brent **71.76 → 118.35 (+64.9%)**; the largest oil-supply disruption ever recorded.
- S&P 500 peak-to-trough **−8.7%** (Feb 25 high 6,946 → Mar 30 low 6,344); an orderly repricing, not a crash — **VIX peaked at only 31** (Mar 27).
- Gold: war-anticipation run-up into a **Mar 2 peak (5,294)**, then **−17.4% to Mar 26 (4,376)**, including a −5.9% single day (Mar 19).
- 10-yr yield: brief flight-to-quality dip to 3.96% (Feb 27), then **rose to 4.44%** (Mar 27) as the oil shock became an inflation shock (CPI later printed 4.2% y/y in May).
- Whipsaw: Brent **−11.3% on Mar 10** (ceasefire hopes) then **+9.2% on Mar 12**. Partial ceasefire Apr 8; re-restricted Apr 19; re-flare to $105 on Jul 23.

## Twelve non-obvious insights (the "huh, really?" list)
1. **The safe haven failed.** The instinctive Mar 2 trade — buy gold — lost ~17% by late March. Mechanism: real yields rose (10y +48bp) and crisis liquidation hit the crowded winner. Clients who fled to gold at the top were down more than the equity market they fled.
2. **Bonds didn't rescue either.** On 11 of the 17 equity down days in the window, the 10-yr yield *rose* — the classic 60/40 diversifier failed on the days it was needed, the 2022 inflation-shock pattern again. Duration was not the hedge; **energy was the only hedge that worked.**
3. **The cheapest insurance was sold 3 days before the war.** VIX closed **17.9 on Feb 25** — with operations visibly brewing — vs 31 a month later. Hedging cost roughly doubled for those who waited for confirmation. "Knowable-from" for cheap hedges: the pre-closure week.
4. **Panic had a one-day price tag.** The single best day of the window (**+2.91%**) was Mar 31 — the day after the trough. A client who capitulated at the Mar 30 close missed it in 24 hours.
5. **It was a drawdown, not a collapse** — −8.7% with VIX ≤31. Advisers who framed it as "a correction with an inflation twist" were more accurate than "crisis" framing, and the calibration mattered for what clients did next.
6. **The whipsaw punished tacticians.** Anyone trading the Mar 10 ceasefire headline was −11% and then +9% within 48 hours. Policy-band rebalancing beat headline trading.
7. **The drawdown was a planning gift:** tax-loss harvesting into the decline, and **Roth conversions at −8% prices** (converting the same shares at a lower taxable value) — both fully knowable in real time, both rare in practice.
8. **Rebalancing bands forced the "scary" trade:** selling the gold that had run up, buying the equities that had fallen — mechanically contrarian, emotionally hard, and exactly right in this window.
9. **Cash "safety" had a new cost:** with the 10-yr at 4.3–4.4% and cuts evaporating, moving to cash meant paying up for comfort while lock-in-able yields sat available — the segue into the Warsh story.
10. **Second-order exposures mattered more than headlines:** clients with Gulf business interests, energy-linked income, shipping/logistics businesses, or travel-heavy lifestyles had real, checkable exposure the market indices don't show. Asking beat telling.
11. **The re-flare rewarded persistence:** hedges quietly kept on (or re-added in early July at Brent $69) paid again on Jul 23 ($105) — after the herd had declared it over.
12. **Concentration risk wore a uniform:** energy-sector employees and business owners got a windfall and a lesson at once — diversify the spike, don't extrapolate it.

## Predictable client questions → strong contemporaneous answers (for classifying the herd)
- "Should I go to cash until this blows over?" → strong answer referenced the cost of exit + re-entry, the one-day rebound risk (see #4), and yield alternatives to cash.
- "Should I buy gold / more gold?" → strong answer flagged the run-up already in the price and rising real yields (see #1).
- "Is this 2020/2008 again?" → strong answer calibrated: supply shock + inflation, not a credit event; drawdown-scale framing (#5).
- "Gas prices are killing me / oil at $100+?" → strong answer separated household budgeting from portfolio action; energy overweight if any was a *hedge*, sized, not a bet.
- "Do something!" → strong answer converted anxiety into the planning checklist (#7, #8) — action that helps instead of action that soothes.

## Playbook with knowability dates (for grading T2/T3 finds)
| Move | Knowable from | Why it was right at the time |
|---|---|---|
| Raise escalation risk; check client Gulf/energy exposure; cheap hedges | **Feb 23–27** (ops brewing, VIX 18–19) | Insurance priced before confirmation |
| Energy/defense hedge or overweight, sized | Feb 27 – Mar 4 | Direct transmission of a Strait closure |
| "Don't chase gold" counsel | Mar 3–6 (after the run to 5,294) | Crowded trade + rising real yields |
| Tax-loss harvesting; Roth conversions at depressed values | Mar 5 onward | Mechanical value from the drawdown |
| Policy-band rebalance INTO equities / out of gold | Mar 12–31 | Bands triggered; contrarian by design |
| Talk client out of capitulation at the lows | Mar 26–30 (VIX 27–31) | See the +2.91% next-day stat |
| Keep/re-add hedges after the "all clear" | Apr 8 → early Jul (Brent $69) | Ceasefire was partial; risk premium mispriced |

## Traps (finding these in notes is as valuable as finding the wins)
Chasing gold at the top · panic-selling Mar 26–30 · trading the ceasefire headlines · abandoning bonds entirely at peak yields · promising clients "it'll recover fast" as a certainty rather than a base case · treating the Apr 8 ceasefire as the end of the story.

---

# CONCISE INSIGHT SETS · OTHER REGISTRY EVENTS

## fed_warsh (Jan chatter; May 15 – Aug 5 core)
- The year's biggest consensus break: markets entered 2026 pricing cuts; after Warsh's **Jun 17** debut (dots erased cuts, hike on table) and the **Jul 29** hold (30-yr >5.19%), they priced a possible **hike**. Advisers who told clients in H1 "the cuts aren't coming — plan as if rates stay high" made every downstream decision better.
- T3 tell: querying/discussing **"Warsh" in January**, when he was a rumored pick — the regime change was scoutable months early.
- The honest nuance: extending duration in May took mark-to-market pain as long yields kept rising into July. The *defensible* wins were (a) not sitting in cash waiting for cuts, (b) **ladders** (which roll up as yields rise), (c) repricing client borrowing early, (d) MYGA/annuity and muni lock-ins for known liabilities. Grade on reasoning, not on the July mark.
- Inflation re-anchoring (CPI 4.2% May) changed client math on mortgages, tuition, and cash drag — advisers who proactively re-ran plans at "higher-for-longer" assumptions were rare.

## spacex_ipo (Apr 1 S-1; Jun 12 IPO; Jun 16 peak $225.64; ~$153 late Jun; Aug 4 earnings)
- The FOMO stat: priced $135 → +67% to the Jun 16 peak → **−32% from peak** within two weeks. Buying the peak vs the offer price was the whole return difference.
- The decade-long signal: real access was built **years earlier** via secondaries/pre-IPO funds — the ultimate "top bankers were early" story if the notes show it.
- The peak was a *planning* window, not just a trading one: gifting appreciated shares to DAFs/trusts in the Jun 13–17 window moved value at maximum prices.
- Standard insider lockups would run ~180 days (≈ early Dec 2026 — verify actual terms): the adviser move for employee/insider clients was hedging/10b5-1/exchange-fund planning *within* constraints, plus the concentration talk.
- Common misconception worth catching: QSBS does **not** apply to buying SPCX at IPO — advisers who correctly killed that idea showed real expertise.
- Softer gem: using the excitement to engage clients' kids (529s, Trump accounts) — acquisition behavior, not investment advice.

## saas_rsu (H1 theme)
- The cruel correlation: software employees' RSUs fell **with** their career risk — same AI-agent disruption. Diversifying RSUs early protected human capital and portfolio at once; that's the most human story in the registry.
- Picks-and-shovels beat incumbents: memory prices +up to 355%, AI-server names ripping while SaaS de-rated — sector rotation *within* tech, invisible at the index level (S&P +11% by Jun 2 while SaaS clients felt a bear market).
- Estate alpha in the wreckage: gifting *depressed* SaaS positions into trusts/GRATs moved future recovery out of the estate at low values.
- Herd tell: "tech is up, why am I down?" — the confusion itself is a findable topic cluster.

## ny_pat (Feb 11 → Sep 18 arc)
- The arc inverted twice: Feb–Mar panic was about an **income-tax** hike that never passed; the tax that *did* pass (May 27) hit **property**. Advisers who told clients in March "watch property, not income tax" were prophetic; those who ran full domicile reviews were prepared either way.
- The money math clients needed: 1.3% on a $25M non-primary home = **$325k/yr**; 0.8% on $10M = $80k/yr. Enough to change sell/hold/restructure math, not enough to justify a panicked fire sale into a buyer's market of fellow PAT sellers.
- The trap with teeth: NY income-tax **domicile** and PAT **primary residence** are different tests — a Florida-domiciled client can still owe PAT on the NYC apartment; conversely 183-day statutory residency can snap back on clients "moving" casually.
- Structuring questions (LLC/trust attribution) were open until the **Jul 14** rules — raising them in June = T3.
- The live deadline: exemption applications by **Sep 18**; notices from Jul 23. Proactive contact before the letter = the differentiator; documentation completeness = the measurable outcome.
- Contrarian angle: motivated PAT sellers created entry points for buyers with primary-residence intent.

## fed_planning (Oct 2025 – Apr 15, 2026)
- The dog that didn't bark: the estate exemption **didn't** sunset — $15M/$30M permanent from Jan 1. The differentiated move was *repurposing* rushed 2025 structures and pivoting to discount-gifting/SLATs/dynasty funding, not undoing planning altogether.
- Calendar alpha, Dec 2025: accelerating charitable gifts ahead of the 2026 **0.5% AGI floor + 35% cap** was a one-time, dated, dollar-quantifiable win (look for a December DAF spike).
- Roth catch-up mandate (prior-yr wages > ~$145k): fixing elections in **Nov–Dec 2025** prevented the January paycheck surprise; the confused-January-call cluster marks the herd.
- First $40k-SALT filing season: PTET elections and itemize-vs-standard re-runs done *before* April = T2.
- Trump accounts fundable ~Jul 2026: a next-gen acquisition tool more than an investment story.
- QSBS 2.0 (post-Jul-4-2025 stock; 50/75/100% at 3/4/5 yrs; $15M cap): founder-client restructuring conversations = deep-expertise tell.

## rates_planning (May 15 → …)
- High §7520/AFR flipped the estate-vehicle menu: **GRATs harder** (high hurdle), **CLATs/QPRTs/CRTs more attractive**, intra-family loans repricing. A vehicle-mix-by-month chart (TOP vs FIELD) is the cleanest visual of adaptive expertise.
- 5%+ long yields made ladders/munis genuinely competitive with equity risk for goal-dated money — "we can now defease the tuition/house with certainty" conversations.
- 401(k) alternatives/crypto (Aug 2025 EO; guidance rolling through 2026): early sponsor/client questions mark the frontier-aware advisers.

## Montage quick facts
BTC peak ~$126k **Oct 6, 2025** then broke down (trimming at the top / harvesting in Nov–Dec = the finds) · gold through $4,000 Oct 2025 · 43-day shutdown Oct 1–Nov 12, 2025 · Maduro captured Jan 3, 2026 · UAE left OPEC May 1, 2026.

---

## Source discipline
Tape numbers = market_daily.csv (Yahoo-sourced, desk spot-check advised). Event dates/figures = verified reporting as of Aug 2026. Tax mechanics = the Jul 4, 2025 act + SECURE 2.0 as enacted; thresholds are indexed — confirm exact current figures with tax counsel before anything client-facing. Nothing in this file is investment, tax, or legal advice; it is an analytical rubric.
