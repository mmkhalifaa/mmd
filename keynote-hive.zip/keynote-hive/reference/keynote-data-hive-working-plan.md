# Year-in-Review Keynote — "The Signal in the Hive"
## Full Working Plan v1 · Window: Oct 2025 – Sep 2026 · Prepared Aug 18, 2026

---

## 0. Concept and narrative spine

**The mechanic:** at 4–6 points in the keynote, you "pop out" of the deck into the data hive and replay a moment of the year in three beats:

1. **THE MOMENT** — date, what happened in the world (one slide, one number).
2. **THE HERD** — what every client called about, what most advisers did (call-volume curve, top topics, median behavior).
3. **THE SIGNAL** — what a small subset of top advisers did *earlier*, or *differently*, and what happened to their clients because of it.

The contrast between beats 2 and 3 is the entire show. Only the hive can produce beat 3.

**The three acts:**
- **Act I — The world shook** (markets & geopolitics): 3–4 moments.
- **Act II — The rules changed** (tax & wealth planning): 2–3 moments. *This is the layer advisers will feel most seen by.*
- **Act III — What our best did**: the synthesis — the recurring signature of top advisers across every moment (they lead, they call out, they connect events).

---

## 1. Definitions to lock BEFORE any analysis (one page, reused everywhere)

### 1.1 Adviser cohorts
Define **Top Decile** by a composite score over the window — *not* AUM:
- Net new money percentile (organic flows)
- Client retention / zero attrition during drawdown months (Mar, Jun–Jul)
- Proactive-contact ratio: outbound touches ÷ inbound touches
- Client behavior score: % of their clients who made no panic liquidations in event windows
Everyone else = **Field**. Optionally a **Bottom Quartile** for internal (not stage) contrast.

### 1.2 Baselines and windows
- Per event: **Pre** (T−10 trading days), **Peak** (event-specific), **Post** (T+30).
- **Quiet baseline**: a matched 4-week window with no registry event (suggest Nov 17 – Dec 12, 2025 and Jan 12 – Feb 6, 2026). All "spike" claims = event rate ÷ quiet-baseline rate.

### 1.3 The three keynote-grade statistics (compute for every event)
| Metric | Definition | Example stage line |
|---|---|---|
| **Lead time** | Days between Top-Decile first action/query on a theme and the Field median | "Our top advisers were researching war-risk hedges 6 days before the Strait closed." |
| **Divergence** | Behaviors with <5% Field prevalence but >30% Top-Decile prevalence | "Only 4% of advisers did X. Among the top decile, 61% did." |
| **Outcome** | Diff-in-diff on client results (drawdown participation, tax saved, retention) | "Their clients captured the rebound; panic-sellers missed 9 points." |

---

## 2. EVENT REGISTRY — Act I: The world shook

### EVENT M1 · The Hormuz war and the oil shock
**Dates:** US/Israel operations begin ~Feb 28 · Iran announces Strait closure **Mar 2** · Brent +~65% in March (peak ~$118) · partial ceasefire **Apr 8**, re-restricted **Apr 19** · US–Iran memorandum June; Brent $69 on **Jul 2** · renewed tanker attacks; Brent $105 on **Jul 23**.
**Pull windows:** `2026-02-16 → 2026-04-24` (core) and `2026-06-25 → 2026-08-07` (re-flare).

**Data to pull**
- Client inbound calls/messages: topic-tagged volume by day; seed terms: *oil, gas prices, Iran, war, sell everything, go to cash, safe, gold, recession*.
- Adviser outbound: count, timing, and content by day; flag outbound placed **Feb 24 – Mar 1** (pre-closure).
- Internal research/system queries: *Hormuz, war risk, energy hedge, tanker, defense stocks, Gulf exposure, oil ETF, TIPS*.
- Trades: energy, defense, gold/commodities, TIPS, structured notes with energy underliers; sell orders placed and **cancelled** Mar 2–13; tax-loss harvesting Mar 10–31.

**Herd (expected):** inbound panic spike Mar 2–6; reactive reassurance; net equity selling at the local low.
**Signal hypotheses (hunt for these):**
1. Advisers querying energy/war-risk topics in the **last week of February**, before closure.
2. Proactive outbound to clients with Gulf business/family/property exposure before Mar 2.
3. Hedges or energy/defense/gold adds placed **before** the spike; trimmed into it.
4. Panic sell orders reversed after one adviser call (measure: cancellation rate after outbound contact).
5. Loss harvesting + **Roth conversions executed in the March drawdown** (converting at depressed values — classic top-adviser move).
6. Who re-hedged in early July before the Jul 23 re-spike, when everyone else had moved on.

**Stat candidates:** lead time on energy queries; % of Gulf-exposed clients called pre-event (Top Decile vs Field); rebound capture of coached vs uncoached clients.

---

### EVENT M2 · The Fed regime change — the rate-cut story dies
**Dates:** last cut **Dec 11, 2025** to 3.50–3.75% · Powell term ends **May 15** · **Warsh sworn in May 22** · first Warsh FOMC **Jun 17**: hold, dot plot erases 2026 cuts, hike on the table · **Jul 29** hold, 3 dissents, 30-yr yield >5.19% · CPI 4.2% y/y in May (3-yr high), 3.5% June. Markets flipped from pricing cuts to pricing a hike.
**Pull windows:** `2026-01-05 → 2026-02-13` (nomination chatter) and `2026-05-15 → 2026-08-05` (core).

**Data to pull**
- Inbound: *mortgage, refinance, when will rates come down, bond fund losing, CD, money market, annuity*.
- Internal queries: *Warsh, Fed chair, duration, bond ladder, lock in yields, 30-year, muni ladder, buffered note*.
- Trades/product: ladder builds, long-duration purchases May 1–Jun 10; sweep-cash movement; lending: refis, portfolio-line repricing, intra-family loans.

**Herd:** "when do rates fall" inbound; complaints on bond funds; waiting for cuts that never came.
**Signal hypotheses:**
1. Advisers researching **"Warsh" in January**, when he was merely a rumored pick — before the Field.
2. Yield lock-ins (ladders, long munis, MYGAs) built in early May **before** the Jun 17 hawkish flip.
3. Advisers who moved client borrowing (refi / restructure) ahead of the long-end selloff.
4. Cash deployed off sweep into 5%+ instruments vs Field's idle cash.
5. Estate-planning pivot on rates (see EVENT T2): high hurdle rates → who shifted from GRATs to CLATs/QPRTs and repriced intra-family loans.

**Stat candidates:** lead time on "Warsh" queries; ladder purchases May vs July (Top Decile vs Field); idle-cash yield differential.

---

### EVENT M3 · SpaceX — the biggest IPO in history
**Dates:** xAI acquisition completed **Feb 2026** · confidential S-1 **Apr 1** · priced $135, lists on Nasdaq (SPCX) **Jun 12** — $75B raised at $1.75T, up to ~30% retail allocation · intraday peak **$225.64 on Jun 16** · ~$153 late June · first earnings **Aug 4**.
**Pull windows:** `2026-03-25 → 2026-04-10` · `2026-06-01 → 2026-06-30` · `2026-08-03 → 2026-08-07`.

**Data to pull**
- Inbound: *SpaceX, SPCX, Starlink, IPO allocation, can I get in, Musk*.
- Adviser outbound + internal queries: *pre-IPO, secondaries, tender, concentration, collar, exchange fund, 10b5-1, QSBS* (note: QSBS won't apply to SPCX itself — flag advisers who correctly said so).
- Trades: SPCX orders Jun 12–30 by direction and timing; pre-IPO fund/secondary positions established **2023–2025** (provenance query); DAF gifts of SPCX; option strategies post-listing.

**Herd:** allocation FOMO; buy orders clustered at the Jun 15–16 top.
**Signal hypotheses:**
1. Advisers who had built clients **pre-IPO exposure via secondaries/funds years earlier** — the ultimate "we saw it coming."
2. Advisers who **trimmed into the Jun 16 spike** while the Field chased.
3. Concentration conversations opened with clients holding large single-stock tech positions — the IPO as the door-opener.
4. **Gifting at the top**: appreciated SPCX (or other inflated positions) moved to DAFs/trusts in the Jun 13–17 window.
5. Next-gen engagement: advisers who used SpaceX to start conversations with clients' kids (pair with EVENT T3 Trump accounts — "invest for the next generation" is a beautiful stage moment).

**Stat candidates:** % of Top-Decile client SPCX buys pre-peak vs Field buys at peak; # of clients with pre-IPO exposure by adviser cohort; DAF-gift dollar spike Jun 13–17.

---

### EVENT M4 · SaaSpocalypse vs. the memory supercycle (running H1 theme)
**Dates:** software de-rated all H1 on AI-agent disruption fears; memory-chip prices up as much as **355%**; AI-server names ripped (Dell +32% in a day post-earnings); S&P +~11% by Jun 2.
**Pull windows:** major earnings weeks Feb–Jun (build exact list from the calendar) + continuous topic tracking `2026-01-02 → 2026-06-30`.

**Data to pull**
- Inbound: *why is my software fund down, [big-cap SaaS names], sell tech, AI bubble*.
- Employer field on client records: clients **employed at software companies** (RSU exposure) — this is the gold vein.
- Trades: rotations software → semis/memory/infrastructure; RSU diversification programs initiated; hedges/collars on concentrated SaaS positions.

**Herd:** confusion inbound ("tech is up but I'm down"); holding losers.
**Signal hypotheses:**
1. Advisers who moved **software-company employees** to diversify RSUs *early in H1* — protecting the client's career risk and portfolio risk at once. This is the single most human "signal" story in Act I.
2. Rotation into picks-and-shovels (memory/infra) before the Field.
3. **Cross-event gem:** gifting *depressed* SaaS positions into GRATs/trusts (low values + future recovery = estate-tax alpha). Links Act I to Act II on stage.
4. Harvested SaaS losses used to fund the March energy hedges (event-to-event chaining — hunt for advisers who did both).

---

### EVENT M5 · Montage (rapid-fire slides, 15 seconds each — pull data only if time permits)
- **Oct 6, 2025** — Bitcoin peaks ~$126k, then breaks down through November (who trimmed at the top; who harvested in Nov–Dec).
- **Oct 2025** — gold through **$4,000**.
- **Oct 1 – Nov 12, 2025** — the 43-day government shutdown.
- **Jan 3, 2026** — Maduro captured in US strike on Venezuela (LatAm-exposed clients).
- **May 1, 2026** — UAE withdraws from OPEC.

---

## 3. EVENT REGISTRY — Act II: The rules changed (tax & wealth planning)

### EVENT T1 · New York's "tax the rich" winter → the pied-à-terre tax ⭐ centerpiece
This is a full arc with FOUR pull windows — anxiety, resolution, implementation, deadline — and it is **live right now**.

**Dates:**
- **Feb 11** — Mamdani testifies in Albany: 2% city income-tax surcharge on $1M+ earners, corporate rate to 11.5%.
- **Feb 17** — preliminary city budget; threat of a **9.5% property-tax increase** as leverage.
- **~Mar 10** — Senate/Assembly one-house budgets back wealth-tax hikes → peak client anxiety.
- **April** — Mamdani + Hochul jointly announce the pied-à-terre proposal; Comptroller revenue report Apr 30.
- **May 27–28** — State budget (~$268B) passes and is signed: **pied-à-terre tax enacted** (Tax Law Art. 30-C); **no income-tax or corporate hikes** (pandemic corporate surcharge extended 3 yrs).
- **Jul 1** — tax effective (FY 2026-27; sunset Jun 30, 2031).
- **Jul 14** — DOF final rules · **Jul 23** — notices begin mailing · **Aug 30** — notification complete.
- **Sep 18, 2026** — exemption-application deadline · **Nov 2026** — first bills (due Jan 1, 2027).

**Mechanics to brief advisers on (Phase 1, Jul 2026–Jun 2028):** 1–3 family homes valued >$5M: 0.8% ($5–15M) / 1.05% ($15–25M) / 1.3% (>$25M) tiers; condos/co-ops: assessed value >$1M, 4.0–6.5%. ~10,000 properties; ~$500M/yr projected. Open questions: LLC/trust attribution, statutory-residency interplay, primary-residence documentation.

**Data to pull**
- Client master: flag clients with **NYC residential property + non-NY primary domicile** (CRM address fields, mortgage collateral, property in balance sheets, trust/LLC-held real estate).
- Inbound by window: Feb–Mar: *leaving New York, move to Florida, Mamdani, taxes going up, sell my apartment*. Jul–Aug: *letter from the city, pied-à-terre, surcharge, exemption, primary residence*.
- Adviser outbound + internal queries: *domicile, statutory residency, 183 days, PAT, Article 30-C, exemption documentation, LLC attribution*.
- Actions: domicile reviews opened; estate-attorney/CPA referrals; property listings/sales; ownership restructurings; exemption filings in flight (vs Sep 18 deadline).

**Herd:** reassurance in Feb–Mar; scramble after the Jul 23 letters; reactive.
**Signal hypotheses:**
1. Advisers who **pre-identified every affected client** and called them *before the Jul 23 letters landed* — with the sell/hold/restructure math already run. Measure: % of affected book contacted proactively in Jun 1 – Jul 22, Top Decile vs Field.
2. Advisers who converted the Feb–Mar anxiety into **full domicile reviews** (multi-year value) instead of one-off reassurance calls.
3. Who looped estate counsel on **LLC/trust attribution** in June, before final rules.
4. Who caught the trap: clients establishing FL domicile whose NYC apartment could be **reclassified** — the domicile test and the PAT primary-residence test are related but not identical.
5. Exemption-readiness: % of affected clients with documentation filed well before **Sep 18** — a stat you can show live on stage.
6. Contrarian: advisers who spotted the **buy side** — clients acquiring NYC trophy property from motivated PAT sellers.

**Stat candidates:** proactive-contact rate on affected clients; lead time (first domicile-review opened vs the Field); Sep 18 filing-readiness by cohort.

---

### EVENT T2 · The new federal planning regime hits (effective Jan 1, 2026 — OBBBA + SECURE 2.0)
The law passed Jul 4, 2025, but **2026 is the year it landed on clients**. Six sub-moments, each with its own pull:

| Sub-event | Key dates / window | What to look for |
|---|---|---|
| **Estate/gift/GST exemption → $15M single / $30M married, permanent** | Pull `2025-10-01 → 2026-03-31` | The sunset panic died. Signal: advisers who **repurposed or unwound** rushed 2025 structures vs set-and-forget; who pivoted to valuation-discount gifting, SLATs, dynasty funding — incl. gifting *depressed* SaaS stock (link to M4). |
| **Mandatory Roth catch-up** (prior-yr wages >$145k must make 401(k) catch-ups as Roth, from Jan 1) | Pull `2025-11-01 → 2026-02-28` | Herd: surprised client calls in Jan when paychecks changed. Signal: advisers who fixed elections in **Nov–Dec 2025** and used it to open Roth-conversion strategy conversations. |
| **First filing season under the $40k SALT cap** (phase-down above $500k MAGI) | Pull `2026-02-01 → 2026-04-15` | Signal: PTET elections prepped in advance; CPA-coordination call volume; itemizing-vs-standard reruns done proactively. |
| **Charitable rules tighten in 2026** (0.5% AGI floor + 35% benefit cap for top bracket) | Pull `2025-11-15 → 2026-01-15` | Herd: business as usual. Signal: advisers who **accelerated client giving into Dec 2025** — DAF funding spike in the top decile before the rules changed. Measurable, dollar-quantifiable, stage-ready. |
| **Trump accounts go live** ($1,000 seed, kids born 2025–28; contributions open ~Jul 2026 — verify exact date) | Pull `2026-06-15 → 2026-08-31` | Signal: advisers using it for **next-gen acquisition** — opening accounts for clients' children/grandchildren, pairing with 529 reviews. Links to the SpaceX next-gen thread. |
| **QSBS 2.0** (stock acquired after Jul 4, 2025: 50/75/100% at 3/4/5 yrs; $15M cap; $75M asset limit) | Continuous | Signal: advisers who flagged founder clients for restructuring/new-issuance planning. Niche, but the ultimate "our advisers know things" flex. |

---

### EVENT T3 · Rates rewired the planning math (bridge between Acts I and II)
With the 30-yr above 5% and the §7520/AFR rates elevated (Warsh era, M2):
**Pull window:** `2026-05-15 → 2026-08-31`.
- **Look for:** GRAT funding *down*, CLAT/QPRT/CRT interest *up* (high hurdle flips the menu); intra-family loans repriced or paid down; muni-ladder builds at 5%+ long yields; portfolio-line-of-credit renegotiations.
- **Signal:** advisers whose planning-vehicle mix visibly rotated with rates; the Field's stayed static. A single chart of "vehicle mix by month, Top Decile vs Field" could be a keynote hero image.
- Also: **401(k) alternatives/crypto** (Aug 2025 executive order; DOL/SEC guidance rolling through 2026 — have the team verify current status): who fielded plan-sponsor and client questions first.

---

## 4. Data pull specification (hand this to engineering / Claude Code)

**Streams and minimum fields (all joined on `adviser_id`, `client_id`, anonymized at export):**

| Stream | Fields |
|---|---|
| `calls` | ts, direction (in/out), adviser_id, client_id, duration, transcript_text, auto_topics[] |
| `emails_msgs` | ts, direction, adviser_id, client_id, subject, body_text |
| `internal_search` | ts, adviser_id, query_text, surface (research portal, CRM, planning tool) |
| `trades` | ts, client_id, adviser_id, instrument, ticker/CUSIP, side, qty, $, order_status (incl. cancelled), account_type |
| `product_ops` | ts, client_id, type (DAF gift, trust funding, GRAT/CLAT, ladder, structured note, refi, exemption filing, account opening incl. minors), $ |
| `crm` | client attributes: domicile state, property records incl. NYC RE + entity ownership, employer, employer industry (SaaS flag), net worth band, next-gen linked contacts |
| `adviser_master` | adviser_id, tenure, region, book size, composite-score inputs (§1.1) |

**Export rules:** hash all IDs; strip names/PII from text before analysis; k≥10 for any aggregate that leaves the analysis environment.

---

## 5. Analysis recipes (what Claude Code runs, per event)

- **R1 · Lift curves** — daily volume by topic per stream, event window ÷ quiet baseline. Output: one chart per event, herd curve vs top-decile curve.
- **R2 · Lead–lag** — first-action date per adviser per theme; distribution by cohort → **lead-time stat**.
- **R3 · Contrarian trade detection** — flag Top-Decile trades opposite in sign or ≥5 days earlier than Field mode (e.g., trimming SPCX Jun 16, buying energy Feb 26).
- **R4 · Rare-behavior mining** — TF-IDF / distinctive n-grams and product codes: Top-Decile transcripts+actions vs Field, per window → **divergence stat** and the "we never would have guessed" list.
- **R5 · Quote miner** — retrieve top-decile adviser lines matching signal hypotheses; output to `quotes_for_review.md` with context, **never** straight to slides (compliance gate).
- **R6 · Outcomes** — diff-in-diff: clients of Top-Decile vs Field on drawdown participation (Mar, Jun–Jul), rebound capture, dollars of tax saved (Dec-2025 giving, Roth timing, PAT exemptions), retention.

**Per-event deliverable:** 1 headline stat + 1 surprising behavior + 1 anonymized quote + 1 chart.

---

## 6. Claude Code kit

**Repo layout**
```
keynote-hive/
├── CLAUDE.md                  # context, schemas, definitions, compliance rules
├── config/
│   ├── event_registry.yaml    # below — the machine-readable version of §2–3
│   └── cohorts.yaml           # §1.1 scoring weights
├── extracts/                  # SQL / pull specs per stream (§4)
├── data/                      # parquet exports (never committed)
├── analysis/                  # r1_lift.py … r6_outcomes.py
└── outputs/<event_id>/        # findings.md, stats.json, chart.png, quotes_for_review.md
```

**CLAUDE.md must contain:** the §1 definitions verbatim; §4 schemas; rule that all outputs are k≥10 aggregates; quotes only ever land in `quotes_for_review.md`; every stat labeled with its baseline.

**`config/event_registry.yaml` (starter — extend with §2–3 detail):**
```yaml
events:
  - id: hormuz_2026
    windows: [{start: 2026-02-16, end: 2026-04-24}, {start: 2026-06-25, end: 2026-08-07}]
    key_dates: {ops_begin: 2026-02-28, closure: 2026-03-02, ceasefire: 2026-04-08, reflare_peak: 2026-07-23}
    seed_terms: [oil, iran, hormuz, war risk, energy hedge, gold, go to cash, tanker]
    hypotheses: [pre_event_queries, proactive_outbound, pre_spike_hedges, cancelled_panic_sells, drawdown_roth_conversions]
  - id: fed_warsh_2026
    windows: [{start: 2026-01-05, end: 2026-02-13}, {start: 2026-05-15, end: 2026-08-05}]
    key_dates: {sworn_in: 2026-05-22, fomc1: 2026-06-17, fomc2: 2026-07-29}
    seed_terms: [warsh, rate cut, mortgage, bond ladder, lock in yield, duration]
  - id: spacex_ipo_2026
    windows: [{start: 2026-03-25, end: 2026-04-10}, {start: 2026-06-01, end: 2026-06-30}, {start: 2026-08-03, end: 2026-08-07}]
    key_dates: {s1_filed: 2026-04-01, ipo: 2026-06-12, peak: 2026-06-16, earnings: 2026-08-04}
    seed_terms: [spacex, spcx, starlink, ipo, allocation, concentration, collar, exchange fund]
  - id: saas_memory_2026
    windows: [{start: 2026-01-02, end: 2026-06-30}]
    seed_terms: [software down, saas, ai bubble, rsu, diversify, memory, semis]
  - id: ny_pat_2026
    windows: [{start: 2026-02-05, end: 2026-03-31}, {start: 2026-05-20, end: 2026-06-05},
              {start: 2026-07-01, end: 2026-09-18}]
    key_dates: {testimony: 2026-02-11, passed: 2026-05-27, effective: 2026-07-01,
                notices: 2026-07-23, exemption_deadline: 2026-09-18}
    seed_terms: [pied-a-terre, leaving new york, domicile, florida, mamdani, exemption, primary residence, surcharge]
  - id: fed_planning_2026
    windows: [{start: 2025-10-01, end: 2026-04-15}]
    key_dates: {roth_catchup: 2026-01-01, exemption_15m: 2026-01-01, charitable_floor: 2026-01-01, filing_deadline: 2026-04-15}
    seed_terms: [roth catch-up, 15 million exemption, salt, ptet, daf, charitable, trump account, qsbs]
  - id: rates_planning_2026
    windows: [{start: 2026-05-15, end: 2026-08-31}]
    seed_terms: [grat, clat, qprt, 7520, afr, intra-family loan, muni ladder]
```

**First three prompts to give Claude Code:**
1. "Read CLAUDE.md and config/. For event `ny_pat_2026`, run R1 on `calls` and `internal_search` across all three windows; output the herd-vs-top-decile lift chart and the top 20 rising topics per window."
2. "Run R2 lead–lag for `hormuz_2026` on internal_search using the seed terms; report the lead-time distribution by cohort and the 10 earliest advisers (hashed IDs)."
3. "Run R4 rare-behavior mining for `spacex_ipo_2026` on trades + product_ops, Jun 8–30; list behaviors with <5% Field prevalence and >30% Top-Decile prevalence."

---

## 7. Execution timeline (3 weeks)

| Week | Work |
|---|---|
| **1** | Lock §1 definitions with sales leadership; engineering delivers §4 extracts to the analysis environment; build cohort scores; validate quiet baselines. |
| **2** | Claude Code runs R1–R4 on all events; daily review of `findings.md`; kill weak events, double down where divergence is biggest. Run R5–R6 on survivors. |
| **3** | Pick the final 5 moments (recommend: Hormuz, PAT, SpaceX, Fed/rates-planning, SaaS-RSU story); compliance review of every stat and quote; build the deck and the live "pop-out" views. |

---

## 8. Compliance & privacy gate (non-negotiable before stage)

- [ ] All IDs hashed at export; no client or adviser names in any analysis output.
- [ ] Every on-stage stat is a k≥10 aggregate with a stated baseline.
- [ ] Quotes: paraphrased or fully de-identified, individually approved by compliance; adviser quotes need the adviser's consent if identifiable.
- [ ] Legal sign-off on describing the PAT/tax content as education, not advice.
- [ ] Data use consistent with client agreements and firm surveillance-data policy (calls recorded for compliance being reused for analytics — confirm with legal).

---

## 9. Fact-check list for the team (dates cited in this plan)

Verify before slides go final:
- Hormuz: closure Mar 2; Brent +65% Mar; ceasefire Apr 8; $69 Jul 2 / $105 Jul 23 — EIA STEO Aug 2026; World Bank Commodity Markets Outlook Apr 2026; congress.gov CRS R45281.
- Fed: Warsh sworn in May 22; Jun 17 & Jul 29 holds at 3.50–3.75%; 30-yr 5.19% — CNBC Fed live blogs Jun 17 / Jul 29, 2026.
- SpaceX: S-1 Apr 1; IPO Jun 12 at $135 ($75B / $1.75T); peak $225.64 Jun 16; earnings Aug 4 — CNBC Aug 4, 2026; smartasset/Motley Fool IPO explainers.
- NY PAT: passed May 27 / signed May 28 (FY26-27 budget, Tax Law Art. 30-C); effective Jul 1; DOF rules Jul 14; notices from Jul 23; exemption deadline Sep 18; first bills Nov — nyc.gov Mayor's Office Jul 23, 2026; Greenberg Traurig / Morgan Lewis / Katten client alerts.
- OBBBA/SECURE 2.0 2026 items ($15M exemption, Roth catch-up threshold, charitable floor, Trump-account go-live date): confirm with tax counsel — thresholds are indexed and guidance was still landing.
