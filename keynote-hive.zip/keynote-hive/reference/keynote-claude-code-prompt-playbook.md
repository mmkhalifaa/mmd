# Keynote Analysis — Claude Code Prompt Playbook
## Every step, every prompt, every data slice · v1 · Aug 18, 2026
### Companion to: keynote-data-hive-working-plan.md

---

# THE ONE-TABLE ANSWER: what to give Claude, and when

Run the steps in this order. "Streams" = your five text sources: **llm_queries** (adviser questions to your internal LLM), **call_notes**, **transcripts**, **emails**, **meeting_notes**. Add trades/CRM extracts if you can get them — every prompt works without them.

| # | Step / Prompt | Data to provide | Date range |
|---|---|---|---|
| 1 | 0.1–0.3 Export, scrub, repo setup | — | Full range: **2025-10-01 → 2026-09-01** |
| 2 | P1.1 Data audit | ALL streams | Full range |
| 3 | P1.2 Quiet baseline | ALL streams | **2025-11-17 → 2025-12-12** AND **2026-01-12 → 2026-02-06** |
| 4 | P1.3 Adviser cohorts | llm_queries + call_notes + transcripts (+ business metrics file if you have one) | Full range |
| 5 | P2 → EVENT **ny_pat** ⭐ run first | ALL streams | **2026-02-05 → 2026-03-31**, **2026-05-20 → 2026-06-10**, **2026-07-01 → latest** |
| 6 | P2 → EVENT **hormuz** | ALL streams | **2026-02-16 → 2026-04-24**, **2026-06-25 → 2026-08-07** |
| 7 | P2 → EVENT **fed_warsh** | ALL streams | **2026-01-05 → 2026-02-13**, **2026-05-15 → 2026-08-05** |
| 8 | P2 → EVENT **spacex_ipo** | ALL streams | **2026-03-25 → 2026-04-10**, **2026-06-01 → 2026-06-30**, **2026-08-03 → 2026-08-07** |
| 9 | P2 → EVENT **saas_rsu** | ALL streams | **2026-01-02 → 2026-06-30** |
| 10 | P2 → EVENT **fed_planning** | ALL streams | **2025-10-01 → 2026-04-15** |
| 11 | P2 → EVENT **rates_planning** | ALL streams | **2026-05-15 → latest** |
| 12 | P2.2 Quote miner (per event) | transcripts + call_notes of that event only | Same as the event |
| 13 | P3.1–P3.4 Cross-event synthesis + verification | the `/outputs/` folders from steps 5–12 + raw files for re-checks | n/a |
| 14 | P4.1–P4.2 Keynote assembly + compliance pack | `/outputs/` | n/a |

---

# PHASE 0 — SETUP (before any prompt)

## Step 0.1 · Export spec (hand to engineering)
One JSONL file per stream per month, named `{stream}_{YYYY-MM}.jsonl`, covering **2025-10-01 → 2026-09-01**:

```
llm_queries:    {ts, adviser_id, query_text, tool_or_surface}
call_notes:     {ts, adviser_id, client_id, note_text}
transcripts:    {ts, adviser_id, client_id, direction(in/out/unknown), duration_sec, transcript_text}
emails:         {ts, adviser_id, client_id, direction, subject, body_text}
meeting_notes:  {ts, adviser_id, client_id, note_text}
optional adviser_metrics: {adviser_id, net_new_money_pctile, retention_pct, book_size_band}
optional client_master:   {client_id, adviser_id, domicile_state, nyc_property_flag, employer_industry, nw_band}
```

## Step 0.2 · Scrub BEFORE the data touches the repo (non-negotiable)
1. Hash `adviser_id` and `client_id` (keep a mapping file OUTSIDE the repo).
2. Run entity redaction on all text fields: names → `[CLIENT]` / `[ADVISER]` / `[PERSON]`, account numbers → `[ACCT]`, emails/phones → `[CONTACT]`.
3. Keep everything inside your approved secure environment. Claude Code should only ever see scrubbed files.

## Step 0.3 · Repo + CLAUDE.md
```
keynote-hive/
├── CLAUDE.md            ← paste the block below
├── data/                ← scrubbed jsonl files
├── outputs/
│   ├── baseline/
│   ├── cohorts/
│   └── {event_id}/
└── review/              ← quotes_for_review.md lands here, humans only
```

**Paste this into `CLAUDE.md` verbatim:**

```markdown
# Project: Year-in-Review Keynote Analysis
You analyze adviser–client interaction data for a wealth manager to find, per market/tax
event: (1) THE HERD — what clients asked about and what most advisers did; (2) THE SIGNAL —
what a small subset of advisers did earlier or differently. Output feeds a keynote.

## Data streams (in /data/, JSONL, one file per stream per month)
llm_queries = adviser questions to our internal LLM (what advisers wanted to know)
call_notes = adviser-written summaries of client calls
transcripts = client call transcripts (direction may be unknown — infer from content, label confidence)
emails, meeting_notes = as named
All IDs are hashed. Text is PII-scrubbed.

## Cohorts (built in outputs/cohorts/cohort_assignments.json)
TOP = top-decile advisers · FIELD = everyone else. Never compare individuals on stage-facing
outputs; only cohorts.

## The three stats that matter (compute for every event)
LEAD TIME: days between TOP's first action/query on a theme and the FIELD median.
DIVERGENCE: behaviors with ≤5% FIELD prevalence but ≥30% TOP prevalence.
OUTCOME: differences in client behavior after adviser contact (e.g., panic language that
stops, follow-through on planning steps).

## Event date cheat sheet (2026 unless noted)
hormuz: ops begin Feb 28 · Strait closed Mar 2 · Brent +65% in Mar (peak ~$118) · ceasefire
  Apr 8 · re-restricted Apr 19 · Brent $69 Jul 2 · re-flare peak $105 Jul 23
fed_warsh: last cut Dec 11 2025 (3.50–3.75%) · Warsh sworn in May 22 · FOMC hold Jun 17
  (dots flip hawkish) · FOMC hold Jul 29 (30-yr >5.19%) · CPI 4.2% y/y May, 3.5% Jun
spacex_ipo: S-1 filed Apr 1 · IPO Jun 12 at $135 (SPCX, $75B, $1.75T) · peak $225.64 Jun 16
  · ~$153 late Jun · first earnings Aug 4
saas_rsu: software de-rating + memory supercycle, all H1
ny_pat: Mamdani Albany testimony Feb 11 · one-house budgets ~Mar 10 · PAT proposal Apr ·
  passed May 27 / signed May 28 · effective Jul 1 · DOF rules Jul 14 · notices from Jul 23 ·
  exemption deadline Sep 18 · first bills Nov (due Jan 1 2027)
fed_planning: effective Jan 1 2026 — estate/gift exemption $15M single/$30M married (permanent);
  mandatory Roth 401(k) catch-up for prior-yr wages >$145k; charitable 0.5% AGI floor + 35%
  benefit cap; first filing season under $40k SALT cap (Feb–Apr 15); Trump accounts fund ~Jul 2026
rates_planning: high §7520/AFR era — GRAT↓, CLAT/QPRT/CRT↑, ladders at 5%+ long yields
Quiet baselines: 2025-11-17→12-12 and 2026-01-12→02-06

## Evidence rules (absolute)
1. Every claim carries doc IDs (filename + line/record) and counts WITH denominators.
2. No doc ID → do not make the claim. "Not found" is a valid, valuable answer.
3. Attribute precisely: client-said vs adviser-said vs adviser-asked-the-system.
4. Every behavior gets a DATE, reported relative to the event anchor date.
5. Never invent, embellish, or round up. Flag low-confidence findings as such.
6. Verbatim text goes ONLY to review/quotes_for_review.md — never into findings or stats.
7. Process files in date order, in batches; keep running tallies; if you sample, say so and how.
8. Stage-facing numbers must be cohort aggregates of n≥10.
```

---

# PHASE 1 — FOUNDATIONS

## PROMPT 1.1 · Data audit
**Give it:** all streams, full range.
```
Read CLAUDE.md. Audit everything in /data/.
Produce outputs/audit.md with: (1) record counts per stream per week, as a table and a
gaps list (any week where a stream drops >50% vs its median — these are pull errors, not
insights); (2) date coverage vs the event cheat sheet — flag any event window with thin
data; (3) field-quality check: % empty text, % missing direction on transcripts, % missing
client_id; (4) 5 random sample records per stream (truncate text to 200 chars) so I can
sanity-check the scrub — flag ANY record where PII survived; (5) a go/no-go list: which
event analyses the data can support today.
Do not analyze content yet.
```

## PROMPT 1.2 · Quiet baseline
**Give it:** all streams, **2025-11-17 → 2025-12-12** and **2026-01-12 → 2026-02-06** only.
```
Read CLAUDE.md. Using only the two quiet-baseline windows in /data/:
1. Build a topic taxonomy of client inbound concerns from call_notes + transcripts + emails
   (target 25–40 topics, e.g., "performance review", "cash needs", "estate question").
2. Compute baseline daily rates: per topic per 100 client interactions; and for llm_queries,
   per theme per 100 queries.
3. Compute baseline behavior rates per adviser per week: outbound-contact rate, planning-topic
   rate, system-query rate.
Save taxonomy + rates to outputs/baseline/topic_rates.json and a 1-page summary in
outputs/baseline/README.md. Every event analysis will divide by these rates, so be precise
about denominators.
```

## PROMPT 1.3 · Adviser cohorts
**Give it:** llm_queries + call_notes + transcripts, full range; plus `adviser_metrics.jsonl` if you have it.
```
Read CLAUDE.md. Build cohort assignments in outputs/cohorts/.
A. If adviser_metrics exists: score = 40% net_new_money_pctile + 30% retention + 30% the
   behavior score below. If not, use the behavior score alone and LABEL the cohort
   "behavior-based" everywhere downstream.
B. Behavior score per adviser (computed from text data over the full range):
   - proactivity: outbound interactions ÷ inbound (from direction fields; infer from content
     where direction is unknown, with confidence flags)
   - anticipation: mean lead time of their llm_queries on event themes vs the field median
     (use the event cheat sheet anchor dates)
   - breadth: # of distinct planning topics they raise with clients per quarter vs baseline
C. Output cohort_assignments.json {adviser_id, score, cohort: TOP|FIELD, inputs}, a
   distribution chart, and a sensitivity note: does the TOP set change materially if weights
   shift ±10%? List (hashed) the top 20 and a random 20 from FIELD for my spot check.
Do not treat cohort membership as a finding; it is an instrument.
```

---

# PHASE 2 — PER-EVENT MINING

## PROMPT 2.1 · The master event prompt (reusable)
Copy this once per event, replacing the `{PARAMETER BLOCK}` with the matching block below. **Give it:** all streams for that event's date ranges + `outputs/baseline/` + `outputs/cohorts/`.

```
Read CLAUDE.md, outputs/baseline/topic_rates.json, outputs/cohorts/cohort_assignments.json.

{PARAMETER BLOCK}

Run the following stages IN ORDER. Write intermediate results to outputs/{event_id}/ as you
go. Think hard at each stage; this is the core analysis.

STAGE 1 — HERD TIMELINE (client side)
From call_notes + transcripts + emails (inbound or client-voiced content): build a
day-by-day timeline of client concerns for the window(s). For each day: interaction count,
top 5 topics, lift vs baseline. Identify the 3 peak days and what specifically clients were
saying on them (themes + emotional register: panic / confusion / FOMO / curiosity — with
doc IDs). Output: herd_timeline.json + a described chart spec.

STAGE 2 — GUIDANCE MAP (adviser side)
From transcripts + call_notes + emails + meeting_notes: extract what ADVISERS told clients.
Cluster the guidance into 5–12 distinct positions (e.g., "stay the course", "add hedge",
"accelerate gift", "do nothing yet"). For each cluster: % of active advisers whose docs
contain it, split TOP vs FIELD, and the median DATE each cohort first gave it. Output:
guidance_map.json.

STAGE 3 — SYSTEM QUERIES (what advisers wanted to know)
From llm_queries: daily volume on event themes (seed terms below + semantic neighbors you
identify). Per adviser: first-query date. Compute the LEAD TIME stat (TOP first-action vs
FIELD median). List the 15 earliest distinct queries verbatim with dates and hashed IDs —
these are keynote gold ("on {date}, an adviser asked our system: ..."). Output:
query_analysis.json.

STAGE 4 — SIGNAL HUNT
(a) Test each hypothesis in the parameter block. Verdict per hypothesis:
SUPPORTED / WEAK / NOT FOUND, with counts+denominators, TOP-vs-FIELD prevalence, and ≥3 doc
IDs for anything supported.
(b) Free hunt: find behaviors, advice, or language present in ≥20% of TOP advisers' docs
and ≤5% of FIELD docs in this window. Look especially for: actions BEFORE the anchor date;
advice that contradicts the herd; connections drawn to OTHER events on the cheat sheet;
specific planning vehicles or products named.
(c) The inverse: anything the FIELD did heavily that TOP conspicuously did NOT do.
Output: signal_findings.md — ranked by "would this surprise a room of advisers?"

STAGE 5 — STAT SHEET
Assemble outputs/{event_id}/stats.json:
{headline_stat, lead_time_days, divergence_items[], herd_peak_day, guidance_split,
 sample_sizes, baselines_used, confidence_notes}
and findings.md (max 1 page): the moment in one line, the herd in three lines, the signal
in five lines, the single best stage stat, and open questions.

Anti-overreach check before finishing: re-read your own findings.md and delete or downgrade
any sentence you cannot tie to specific doc IDs and counts.
```

## Parameter blocks (paste one into the master prompt)

**EVENT ny_pat ⭐ run this first — it's live, and the Sep 18 deadline stat updates daily**
```
event_id: ny_pat
anchor_dates: testimony 2026-02-11 · passed 2026-05-27 · effective 2026-07-01 ·
  notices 2026-07-23 · exemption deadline 2026-09-18
windows: 2026-02-05→03-31 (anxiety) · 2026-05-20→06-10 (resolution) · 2026-07-01→latest (letters)
seed_terms: pied-a-terre, pied a terre, surcharge, non-primary residence, leaving new york,
  moving to florida, mamdani, hochul, domicile, statutory residency, 183 days, exemption,
  DOF letter, second home tax
hypotheses:
 H1 TOP advisers contacted affected clients (NYC property + out-of-state domicile signals in
    the text) BEFORE the Jul 23 letters; FIELD reacted after.
 H2 TOP converted Feb–Mar anxiety into full domicile reviews (multi-topic planning docs),
    not one-off reassurance.
 H3 TOP raised LLC/trust ownership attribution questions in Jun, pre-final-rules.
 H4 TOP flagged the trap that income-tax domicile and PAT primary-residence tests differ.
 H5 TOP are ahead on exemption documentation vs the Sep 18 deadline.
 H6 Contrarian: any adviser framing PAT as a BUYING opportunity (motivated sellers).
```

**EVENT hormuz**
```
event_id: hormuz
anchor_dates: ops 2026-02-28 · closure 2026-03-02 · ceasefire 2026-04-08 · re-flare 2026-07-23
windows: 2026-02-16→04-24 · 2026-06-25→08-07
seed_terms: oil, iran, hormuz, strait, war, gas prices, energy, gold, tanker, go to cash,
  sell everything, hedge, defense stocks, TIPS, safe haven
hypotheses:
 H1 TOP queried war-risk/energy themes in the LAST WEEK OF FEBRUARY, pre-closure.
 H2 TOP made proactive outbound to Gulf-exposed clients before Mar 2.
 H3 TOP guidance clustered on hedging/rebalancing BEFORE the spike; FIELD on reassurance after.
 H4 Panic language in client calls stops after one TOP outbound (trace client threads).
 H5 TOP discussed Roth conversions / loss harvesting DURING the March drawdown.
 H6 TOP re-raised hedging in early July before the Jul 23 re-spike, when FIELD had moved on.
```

**EVENT fed_warsh**
```
event_id: fed_warsh
anchor_dates: sworn in 2026-05-22 · FOMC 2026-06-17 · FOMC 2026-07-29
windows: 2026-01-05→02-13 · 2026-05-15→08-05
seed_terms: warsh, fed chair, rate cut, rate hike, mortgage, refinance, bond ladder, lock in
  yield, duration, money market, CD, muni, when will rates come down
hypotheses:
 H1 TOP queried "Warsh" in January, when he was a rumored pick.
 H2 TOP advised yield lock-ins (ladders, long munis) in early May, BEFORE Jun 17 flipped
    consensus from cuts to a possible hike.
 H3 TOP proactively repriced client borrowing before the long end sold off.
 H4 FIELD guidance = "wait for cuts"; TOP guidance = "cuts aren't coming, act now" — measure
    the split and the dates.
```

**EVENT spacex_ipo**
```
event_id: spacex_ipo
anchor_dates: S-1 2026-04-01 · IPO 2026-06-12 · peak 2026-06-16 · earnings 2026-08-04
windows: 2026-03-25→04-10 · 2026-06-01→06-30 · 2026-08-03→08-07
seed_terms: spacex, spcx, starlink, musk, ipo, allocation, get in, pre-ipo, secondaries,
  tender, concentration, collar, exchange fund, gift shares, DAF
hypotheses:
 H1 Some TOP advisers had positioned clients in pre-IPO exposure years earlier — look for
    references to existing SpaceX/secondary positions in Apr–Jun docs.
 H2 TOP counseled trimming/discipline INTO the Jun 15–17 peak while FIELD fielded FOMO.
 H3 TOP used the IPO to open concentration-risk conversations with single-stock-heavy clients.
 H4 Gifting at the top: DAF/trust gifting discussions dated Jun 13–17.
 H5 Next-gen: advisers using SpaceX excitement to engage clients' children (link to Trump
    accounts / 529 mentions).
```

**EVENT saas_rsu**
```
event_id: saas_rsu
anchor_dates: none (H1 theme); use monthly aggregation
windows: 2026-01-02→06-30
seed_terms: software down, saas, my fund is down, ai bubble, agents, rsu, vesting,
  diversify, concentrated stock, memory, semiconductors, sell my shares
hypotheses:
 H1 TOP moved software-company-employee clients (RSU mentions + employer references) to
    diversify EARLY in H1; FIELD reacted to losses later or not at all.
 H2 TOP rotated client conversations to infrastructure/memory beneficiaries before FIELD.
 H3 Cross-event: TOP discussed gifting DEPRESSED software positions into trusts/GRATs
    (estate alpha on low valuations).
 H4 Cross-event: harvested software losses funding March energy hedges (same client threads).
```

**EVENT fed_planning**
```
event_id: fed_planning
anchor_dates: rules effective 2026-01-01 · filing deadline 2026-04-15
windows: 2025-10-01→2026-04-15
seed_terms: roth catch-up, catch up contribution, 15 million, exemption, gift, SLAT, dynasty,
  salt cap, ptet, itemize, DAF, donor advised, charitable, bunching, trump account, 529, qsbs
hypotheses:
 H1 TOP fixed clients' Roth catch-up elections in Nov–Dec 2025; FIELD fielded confused calls
    in Jan when paychecks changed.
 H2 TOP accelerated client charitable giving into Dec 2025 ahead of the 2026 floor/cap —
    look for a Dec DAF spike concentrated in TOP books.
 H3 TOP repurposed or unwound rushed 2025 estate structures; FIELD left them untouched.
 H4 TOP prepped PTET/SALT strategy pre-filing-season; FIELD scrambled in April.
 H5 Since ~Jul 2026 (out of window — note only), Trump-account questions appear; tag for the
    rates_planning run.
```

**EVENT rates_planning**
```
event_id: rates_planning
anchor_dates: FOMC 2026-06-17 (consensus flip)
windows: 2026-05-15→latest
seed_terms: grat, clat, crt, qprt, 7520, afr, intra-family loan, hurdle rate, muni ladder,
  line of credit, trump account, open account for my kids, 401k private equity, crypto 401k
hypotheses:
 H1 TOP's planning-vehicle mix visibly rotated with rates (GRAT mentions down, CLAT/QPRT/CRT
    and ladder mentions up); FIELD static. Build the "vehicle mix by month, TOP vs FIELD" table.
 H2 TOP repriced/paid down intra-family loans as AFRs rose.
 H3 TOP fielded (or seeded) the first 401(k)-alternatives and Trump-account conversations.
```

## PROMPT 2.2 · Quote miner (run once per event, after 2.1)
**Give it:** transcripts + call_notes for that event's windows + that event's `signal_findings.md`.
```
Read CLAUDE.md and outputs/{event_id}/signal_findings.md. From transcripts and call_notes in
the event windows, extract up to 15 verbatim quote candidates that ILLUSTRATE the supported
findings: client herd quotes (the fear/FOMO in their words), adviser signal quotes (the
early/contrarian advice in their words), and adviser system queries worth reading on stage.
For each: quote, speaker role, date, doc ID, which finding it evidences, and a suggested
anonymized paraphrase. Write ONLY to review/quotes_for_review.md. Flag any quote that could
identify a person even after scrubbing. Do not reference these quotes anywhere else.
```

---

# PHASE 3 — CROSS-EVENT SYNTHESIS

## PROMPT 3.1 · The signature of top advisers
**Give it:** all `/outputs/{event_id}/` folders.
```
Read every stats.json, findings.md, guidance_map.json, query_analysis.json across events.
Answer: what is the recurring SIGNATURE of TOP advisers across the year? Test these candidate
signatures and propose others: (1) they act BEFORE anchor dates (aggregate lead-time
distribution across all events); (2) they are proactive (outbound-first share per event);
(3) they CONNECT events (docs referencing 2+ registry events — the loss-harvest→hedge,
drawdown→Roth, depressed-stock→gift chains); (4) they translate markets into PLANNING (share
of their event docs containing planning topics vs FIELD). Output signature.md with the 3
strongest cross-event stats, each traceable to per-event evidence, and one sentence each on
why a room of advisers would find it surprising.
```

## PROMPT 3.2 · The "nobody saw this coming" list
```
From all signal_findings.md files, compile the 10 most surprising, non-obvious findings of
the year, ranked by: (a) rarity (how few advisers did it), (b) foresight (how early),
(c) client impact, (d) how vividly it demos the data hive on stage. For each: one-line
stage phrasing, the exact stat behind it, doc-ID evidence list, and a confidence grade A–C.
Exclude anything graded C from the top 10. Output: outputs/top10.md
```

## PROMPT 3.3 · Adversarial verification (do not skip)
**Give it:** `/outputs/` + the raw data files.
```
You are now the skeptic. For every statistic in every stats.json and in top10.md and
signature.md: recompute it from the raw /data/ files, independently of the earlier run.
Report a verification table: stat | original | recomputed | match? | notes. For any mismatch
or any stat you cannot reproduce, mark it FAILED and remove it from a corrected top10_verified.md.
Also check: denominators consistent? cohort n≥10 everywhere? any stat sensitive to the
cohort-weight ±10% variants from Phase 1.3? This output is what goes to the keynote team —
nothing unverified survives.
```

## PROMPT 3.4 · Null-results and honesty file
```
Compile outputs/what_we_did_not_find.md: every hypothesis marked WEAK or NOT FOUND across
events, in one list. This protects the keynote: nothing on stage should contradict it, and
some null results are themselves stories ("everyone expects X; our data shows it didn't
happen").
```

---

# PHASE 4 — KEYNOTE ASSEMBLY

## PROMPT 4.1 · Moment scripts
**Give it:** `/outputs/` incl. `top10_verified.md`, `signature.md`.
```
Draft outputs/keynote/moment_scripts.md: for each of the 5 strongest events (recommend
ny_pat, hormuz, spacex_ipo, fed_warsh + rates_planning combined, saas_rsu), write the
three-beat stage script: THE MOMENT (date + one number), THE HERD (the call-volume curve +
2 lines of what clients were saying), THE SIGNAL (the verified stat + the behavior + a
[QUOTE PLACEHOLDER] tag pointing at review/quotes_for_review.md line numbers — do not
insert quote text). ≤120 words per moment. Close with the Act III synthesis using
signature.md. Every number must carry a footnote to its stats.json source.
```

## PROMPT 4.2 · Compliance pack
```
Produce outputs/keynote/compliance_pack.md: every statistic appearing in moment_scripts.md
with: definition, numerator, denominator, date range, baseline, cohort sizes, source files,
verification status from 3.3. Plus the list of quote placeholders awaiting human+compliance
approval. This is the document legal signs.
```

---

# RUN ORDER RECAP & PRACTICAL NOTES

1. **0.1–0.3 → P1.1 → P1.2 → P1.3** must run in that order; everything else depends on baseline + cohorts.
2. Then run **ny_pat first** (step 5): the Sep 18 exemption deadline means H5 produces a stat you can act on *before* the keynote — advisers can still call clients. The keynote line writes itself: "and because we saw it in the hive, every affected client was covered before the deadline."
3. Events 6–11 can run in parallel sessions if you have the quota; each is independent once Phase 1 is done.
4. **Never skip P3.3.** LLM analyses over large corpora drift toward flattering numbers; the adversarial recompute is what makes the stats stage-safe.
5. Expect Phase 2 to surface new hypotheses. Add them to the parameter block and re-run Stage 4 only — the prompts are designed so stages re-run independently.
6. If a stream is missing for a window (P1.1 will tell you), run the event anyway and let the findings note the gap — do not let perfect data block the timeline.
