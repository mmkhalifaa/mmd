# Keynote Hive — Year-in-Review Analysis Workspace
Start here:
- **Pilot test:** put the scrubbed call-notes export in `data/` (see PILOT.md for the spec), open Claude Code in this folder, and say: "Read PILOT.md and run the test."
- **Full build (after the pilot):** say: "Read MISSION.md — we're going to work on this together."
- `ADVISER_EVENT_INSIGHTS.md` = grading rubric · `data/market_daily.csv` = validated market tape · `reference/` = the human-facing plan and prompt playbook · `tools/` = market-data pull script.
**Never commit client data.** `data/call_notes*` and `work/` are gitignored — keep it that way.
