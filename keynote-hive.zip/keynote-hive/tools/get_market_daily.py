"""
get_market_daily.py — builds market_daily.csv for the pilot (Feb 20 -> Mar 31, 2026).

Run this on any machine WITH internet access (not the offline Claude Code box):
    pip install yfinance pandas
    python get_market_daily.py

Prefer your firm's data? Skip this script and fill market_daily_TEMPLATE.csv from
Bloomberg instead — the schema is all that matters. Excel one-liners per column:
    =BDH("SPX Index","PX_LAST","2/20/2026","3/31/2026")
    =BDH("VIX Index","PX_LAST",...)   =BDH("CO1 Comdty","PX_LAST",...)
    =BDH("XAU Curncy","PX_LAST",...)  =BDH("USGG10YR Index","PX_LAST",...)
"""

import pandas as pd
import yfinance as yf

START, END_EXCL = "2026-02-20", "2026-04-01"   # end is exclusive in yfinance
OUT = "market_daily.csv"

TICKERS = {
    "spx_close":    "^GSPC",   # S&P 500
    "vix_close":    "^VIX",    # CBOE VIX
    "brent_close":  "BZ=F",    # ICE Brent front-month future
    "gold_close":   "GC=F",    # COMEX gold front-month (~spot)
    "ust10y_yield": "^TNX",    # CBOE 10-yr yield index = yield * 10
}

frames = {}
for col, tkr in TICKERS.items():
    px = yf.download(tkr, start=START, end=END_EXCL, progress=False)["Close"]
    if isinstance(px, pd.DataFrame):          # newer yfinance returns a frame
        px = px.iloc[:, 0]
    frames[col] = px

df = pd.DataFrame(frames)
df["ust10y_yield"] = df["ust10y_yield"] / 10.0            # ^TNX 48.5 -> 4.85%

# Align to NYSE business days; futures trade some days equities don't and vice versa.
bdays = pd.bdate_range("2026-02-20", "2026-03-31")        # 28 days, no US holidays in window
df = df.reindex(bdays)
filled = df.isna()
df = df.ffill()
df.index.name = "date"
df = df.round({"spx_close": 2, "vix_close": 2, "brent_close": 2,
               "gold_close": 2, "ust10y_yield": 3})

# ---- Sanity checks against independently verified anchors ---------------------
problems = []
if len(df) != 28:
    problems.append(f"Expected 28 trading days, got {len(df)}.")
if df.isna().any().any():
    problems.append(f"NaNs remain in: {list(df.columns[df.isna().any()])}")
feb20_brent = df.loc["2026-02-20", "brent_close"]
mar_brent_max = df.loc["2026-03-01":"2026-03-31", "brent_close"].max()
# Reported: Brent rose ~65% during March 2026 after the Mar 2 Hormuz closure, peaking ~ $118.
if not mar_brent_max > feb20_brent * 1.3:
    problems.append(
        f"Brent March max ({mar_brent_max}) is not >>30% above Feb 20 ({feb20_brent}) — "
        "wrong ticker/units? Expected a ~65% March surge per reporting.")
if not (90 <= mar_brent_max <= 140):
    problems.append(f"Brent March peak {mar_brent_max} outside plausible reported range (~$118).")
spx_early_mar_min = df.loc["2026-03-02":"2026-03-13", "spx_close"].min()
if not spx_early_mar_min < df.loc["2026-02-27", "spx_close"]:
    problems.append("No early-March equity drawdown visible — check SPX series.")
n_ffill = int(filled.sum().sum())

df.to_csv(OUT)
print(f"Wrote {OUT}: {len(df)} rows x {len(df.columns)} cols; {n_ffill} cells forward-filled (holiday mismatches).")
if problems:
    print("\n*** CHECK BEFORE USING — do NOT hand to Claude Code until resolved: ***")
    for p in problems:
        print(" -", p)
else:
    print("Sanity checks passed. Have someone eyeball 3 random rows against the terminal, then ship it.")
